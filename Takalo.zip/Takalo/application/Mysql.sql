

drop database commerce;
create database commerce;
use commerce;

create table produits(
    idproduit integer primary key auto_increment,
    nom varchar(20),
    marque varchar(20),
    disponible varchar(3),
    prix decimal
);

create table marque(
    idMarque integer primary key auto_increment,
    nom varchar(20)
);

insert into produits values (null,'Air Jordan','nike','oui',20000);
insert into produits values (null,'Air Force','nike','oui',20000);
insert into produits values (null,'Air Max','nike','oui',40000);
insert into produits values (null,'stan','adidas','oui',20000);
insert into produits values (null,'S0-01','reebook','oui',10000);
insert into produits values (null,'SD-04','Kapa','oui',20000);
insert into produits values (null,'SD-52','Gucci','oui',25000);
insert into produits values (null,'SD-54','adidas','oui',20000);
insert into produits values (null,'TR-88','REBOOK','oui',30000);




