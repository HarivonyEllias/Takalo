<?php
class Objet extends CI_model{
    public $idObjet;
    public $idClient;
    public $idCategorie;
    public $name;
    public $description;
    public $image;
    public $price;
    public $date;

    public function __construct($objet_row=NULL) {
        if($objet_row!=null){
            $this->idObjet = $objet_row['idObjet'];
            $this->idClient = $objet_row['idClient'];
            $this->idCategorie = $objet_row['idCategorie'];
            $this->name = $objet_row['name'];
            $this->description = $objet_row['description'];
            $this->image = $objet_row['image'];
            $this->price = $objet_row['price'];
        }
    }

    public function getIdObjet(){
        return $this->idObjet;
    }

    public function getIdClient(){
        return $this->idClient;
    }

    public function getIdCategorie(){
        return $this->idClient;
    }

     public function getName(){
        return $this->name;
    }

     public function getDescription(){
        return $this->description;
    }

     public function getImage(){
        return $this->image;
    }

     public function getPrice(){
        return $this->price;
    }

     public function getDate(){
        return $this->date;
    }

    public function getClientName(){
        $query=$this->db->query("select name from client where idclient=".$this->getIdClient());
        $tab=array();
        $tab[0]=$query->result_array();
        return $tab[0][0]['name'];
    }
    //setters

    public function setIdObjet($id){
        $this->idObjet=$id;
    }

    public function setIdClient($id){
        $this->idClient=$id;
    }

    public function setIdCategorie($id){
        $this->idCategorie=$id;
    }

     public function setName($name){
        $this->name=$name;
    }

     public function setDescription($desc){
        $this->description=$desc;
    }

     public function setImage($image){
        $this->image=$image;
    }

     public function setPrice($price){
        $this->price=$price;
    }

     public function setDate($date){
        $this->date=$date;
    }

    public function Hello($name){
        $val = "Bonjour Mr ".$name;
        echo $val;
    }

    //functions
    public function delete(){
        $query=$this->db->query("delete from objet where idObjet=".$this->getIdObjet());
    }
    public function add(){
        $query=$this->db->query("insert into objet values (null,".$this->getIdClient().",".$this->getIdCategorie().",'".$this->getName()."','".$this->getDescription()."','"
        .$this->getImage()."',".$this->getPrice()."'".$this->getDate()."')"
        );
    }
    public function search($tofind,$filter){
        if($filter=="all"){
            $query=$this->db->query("select * from objet where name like '%".$tofind."%' or description like '%".$tofind."%'");
            $tab['data']=array();
            foreach($query->result_array() as $objet_row){
                array_push($tab['data'],new Objet($objet_row));
            }
            return $tab['data'];
        } else{
            $query=$this->db->query("select * from objet where (name like '%".$tofind."%' or description like '%".$tofind."%') and idCategorie=".$filter);
            $tab['data']=array();
            foreach($query->result_array() as $objet_row){
                array_push($tab['data'],new Objet($objet_row));
            }
            return $tab['data'];    
        }
    }
    public function getAll(){
        $query=$this->db->query("select * from objet");
        $tab['data']=array();
        foreach($query->result_array() as $objet_row){
            array_push($tab['data'],new Objet($objet_row));
        }
        return $tab['data'];
    }
    public function getObjetById($id){
        $query=$this->db->query("select * from objet where idObjet=".$id);
        $tab['data']=array();
        foreach($query->result_array() as $objet_row){
            array_push($tab['data'],new Objet($objet_row));
        }
        return $tab['data'][0];
    }
}
