<?php
class Categorie extends CI_model{
    public $idCategorie;
    public $name;

    public function __construct($categorie_row=NULL) {
        if($categorie_row!=null){
            $this->idCategorie = $categorie_row['idCategorie'];
            $this->name = $categorie_row['name'];
        }
    }
    //getters
    public function getName(){
        return $this->name;
    }

    public function getIdCategorie(){
        return $this->idCategorie;
    }
    //setters
    public function setName($name){
        $this->name=$name;
    }
    public function setIdCategorie($idCategorie){
        $this->idCategorie=$idCategorie;
    }
    //function
    public function check(){
        $query=$this->db->query("select * from client where name='".$this->getName()."' and password='".$this->getPassword()."'");
        return (count($query->result_array())==0)?false:true;
    }
    public function getAll(){
        $query=$this->db->query("select * from categorie");
        $tab['data']=array();
        foreach($query->result_array() as $categorie_row){
            array_push($tab['data'],new Categorie($categorie_row));
        }
        return $tab['data'];
    }
    public function getAllObjet(){
        $this->load->model('Objet');
        $query = $this->db->query("SELECT * FROM objet WHERE idcategorie = " . $this->getIdCategorie());
        $tab['data'] = array();
        foreach($query->result_array() as $objet_row){
            array_push($tab['data'], new Objet($objet_row));
        }
        return $tab['data'];
    }
}
