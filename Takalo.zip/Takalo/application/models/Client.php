<?php
class Client extends CI_model{
    public $name;
    public $email;
    public $password;


    public function __construct($client_row=NULL) {
        if($client_row!=null){
            $this->name = $client_row['name'];
            $this->email = $client_row['email'];
            $this->password = $client_row['password'];
        }
    }
    //getters
    public function getName(){
        return $this->name;
    }

    public function getEmail(){
        return $this->email;
    }

    public function getPassword(){
        return $this->password;
    }
    //setters
    public function setName($name){
        $this->name=$name;
    }
    public function setEmail($email){
        $this->email=$email;
    }
    public function setPassword($password){
        $this->password=$password;
    }
    //function
    public function check(){
        $query=$this->db->query("select * from client where name='".$this->getName()."' and password='".$this->getPassword()."'");
        return (count($query->result_array())==0)?false:true;
    }
    public function insert_client($name, $email, $password){
        $data = array(
            'name' => $name,
            'email' => $email,
            'password' => $password
        );
        return $this->db->insert('client', $data);
    }
}
