drop database takalo;
create database takalo;
use takalo;

create table client(
    idClient integer primary key AUTO_INCREMENT,
    name varchar(40),
    email varchar(40),
    password varchar(40)
);
insert into client values (1,'Irina','irina@gmail.com','irina');
insert into client values (2,'Ellias','ellias@gmail.com','ellias');
insert into client values (3,'Mano','Mano@gmail.com','mano');

create table categorie(
    idCategorie integer primary key AUTO_INCREMENT,
    name varchar(40)
);
insert into categorie values (null,'Vetement');
insert into categorie values (null,'Chaussure');
insert into categorie values (null,'Accessoire');
insert into categorie values (null,'Music');
insert into categorie values (null,'sac');

create table objet(
    idObjet integer primary key AUTO_INCREMENT,
    idClient integer,
    idCategorie integer,
    name varchar(30),
    description varchar(150),
    image varchar(20),
    price float,
    foreign key (idClient) references client(idClient),
    foreign key (idCategorie) references categorie(idCategorie)
);
insert into objet values (null,1,2,'NIKE Air Jordan','For good look','(1)',100000);
insert into objet values (null,1,5,'Sac oche vert','Voyage','(2)',100000);
insert into objet values (null,3,1,'Robe de Plage','classique','(3)',100000);
insert into objet values (null,2,2,'Talon blanc','classe blanche','(4)',100000);
insert into objet values (null,3,1,'Robe blanche','Rehefa hanambady','(5)',100000);
insert into objet values (null,2,1,'Pull','Noir sans shoulder','(6)',100000);
insert into objet values (null,1,1,'Robe Noir','long','(7)',100000);
insert into objet values (null,3,2,'Tennis Blanche','Pt 45-75 ','(8)',100000);
insert into objet values (null,1,3,'Robe theatrale','Blanche decoration','(9)',100000);
insert into objet values (null,2,4,'Guitare flea','Clean sound','(10)',100000);
insert into objet values (null,1,4,'AccoustElectric','For Jazz','(11)',100000);
