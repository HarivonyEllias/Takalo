<link rel="stylesheet" href="css/NewForm.css">

<div class="container">
    <br>
    <div class="creer">
       New Categorie
    </div>



    <form action="<?php echo site_url('Controller_Login'); ?>" method="post">

      <div class="mail">
        <div class="input-block">
          <input class="email" type="text" name="user"  id="input-text"  required spellcheck="false">
          <span class="placeholder">nom du Categorie</span>
        </div>
      </div>

      <div class="confirmer">
        <div class="login">
          <a href="<?php echo site_url('Sign'); ?>">Confirmer</a>
        </div>
        <div class="submit">
          <input type="submit">
        </div>
      </div>

    </form>

    <div class="footer">
      <p>Malagasy(Madagascar)<select name="" id=""></select></p>
      <p>By Mano</p>
      <p>Confidentialite</p>
      <p>Conditions d'utilisation</p>
  </div>
  </div>