<?php
// var_dump($search_result);
  $this->load->model('Objet');
  $o=new Objet();
  $objets=$o->getAll();
?>
<link rel="stylesheet" href="css/ListeObjet.css">

<style>
.book-cell:nth-child(1) {
    background-color: #fbadaf;
  }
  .book-cell:nth-child(2) {
    background-color: #a4ebae;
  }
  .book-cell:nth-child(3) {
    background-color: #edb9d6;
  }
  .book-cell:nth-child(4) {
    background-color: #fdca95;
  }
  .book-cell:nth-child(5) {
    background-color: #cbb5e2;
  }
  
</style>


<div class="all">
<?php for ($i=1; $i < count($objets); $i++) { ?>
  <div class="book-cell">
          <div class="book-img">
          <img src="css/photo/<?php echo $objets[$i]->getImage(); ?>.jpg" alt="" class="book-photo">
          </div>
          <div class="book-content">
          <div class="book-title"><?php echo $objets[$i]->getName(); ?></div>
          <div class="book-author"><?php echo $objets[$i]->getClientName(); ?></div>
          <div class="book-sum"><?php echo $objets[$i]->getDescription(); ?></div>
          <a href="<?php echo site_url('Delete')."?id=".$objets[$i]->getIdObjet(); ?>"><div class="book-see">Delete</div></a>
          </div>
        </div>
          <?php } ?>
</div>
