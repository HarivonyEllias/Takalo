<?php
  $this->load->model('Categorie');
  $c=new Categorie();
  $categories=$c->getAll();
// var_dump($search_result);
  $this->load->model('Objet');
  $o=new Objet();
  $objets=$o->getAll();
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Book Store UI</title>
  <link rel='stylesheet' href='css/Jquery/flickity.css'>
  <link rel="stylesheet" href="css/Interface.css">
</head>
<body>

<div class="book-store">
 <div class="header">
  <div class="header-title"><img src="css/logo.png" width="120px" heigth="50px"></div>

  <form action="<?php echo site_url('Search'); ?>" method="get">
  <div class="browse">
   <div class="browse-category">
   <select name="category_filter" id="" style="border:none;">
    <option value="" disable selected>Browse Category</option>
    <option value="all" >All</option>
    <?php foreach ($categories as $categorie) {?>
      <option value="<?php echo $categorie->getIdCategorie(); ?>" ><?php echo $categorie->getName(); ?></option>
    <?php } ?>
   </select>
   </div>

   <div class="search-bar">
      <input type="text" placeholder="Search..." name="search"/>
      <input type="submit" value="ok" style="display:none" />
    </div>
  </form>


  </div>
 </div>


    <div class="book-slide">

      <div class="book js-flickity" data-flickity-options='{ "wrapAround": true }'>

        <?php for ($i=0; $i < count($objets); $i++) { ?>
          <div class="book-cell">
                <div class="book-img">
                <img src="css/photo/(<?php echo $i ?>).jpg" alt="" class="book-photo">
                </div>
                <div class="book-content">
                <div class="book-title"><?php echo $objets[$i]->getName(); ?></div>
                <div class="book-author"><?php echo $objets[$i]->getClientName(); ?></div>
                <div class="book-sum"><?php echo $objets[$i]->getDescription(); ?></div>
                <div class="book-see">Propose</div>
                </div>
              </div>
          <?php } ?>

      </div>
    </div>

    <div class="categorie">
        <h3>Categorie</h3>
            <div class="ctg">
                <table  class="tab">
            <?php foreach ($categories as $categorie) {?>
                <form action="<?php echo site_url('Filter') ?>" method="get">
                <input type="hidden" name="idcategorie" value="<?php echo $categorie->getIdCategorie(); ?>" style="display:none">
                <td><input type="submit" class="ctgs" value="<?php echo $categorie->getName(); ?>"></td>
                </form>
            <?php } ?>
                <script>
            const links = document.querySelectorAll('td');
            links.forEach(link => {
            link.addEventListener('click', function() {
                links.forEach(link => {
                link.style.border = '';
                link.style.width = '';
                link.style.height = '';
                });
                this.style.borderTop = '2px solid #0fa823';
                this.style.borderLeft = '1px solid #9e9e9e90';
                this.style.borderRight = '1px solid #9e9e9e90';
                this.style.borderBottom = '2px solid white';
            });
            });
            </script>

                </table>
        </div>
    </div>

<div class="ParCtg">
<?php 
  if (isset($search_result) && $search_result!=null ) {
  foreach ($search_result as $result) { ?>
        <div class="book-cell2">
                <div class="book-img2">
                    <img src="css/photo/(<?php echo $i ?>).jpg" alt="" class="book-photo2">
                    </div>
                    <div class="book-content two">
                    <div class="book-title two"><?php echo $result->getName(); ?></div>
                    <div class="book-author two">by <?php echo $result->getClientName(); ?></div>
                    <div class="book-sum two"><?php echo $result->getDescription(); ?></div>
                    <div class="book-see2">Echange</div>
                    <a href="#" class="book-see2" value="Click" onClick="Show()">see</a>
                </div>
        </div>
<?php  }
} if(isset($search_result) && $search_result==null) {
  echo "No search results found.";
} ?>

<?php if(!isset($search_result) && isset($filtered_data)){ for ($i=0; $i < count($filtered_data); $i++) { ?>
        <div class="book-cell2">
            <div class="book-img2">
                <img src="css/photo/(<?php echo $i ?>).jpg" alt="" class="book-photo2">
            </div>
            <div class="book-content two">
                <div class="book-title two"><?php echo $filtered_data[$i]->getName(); ?></div>
                <div class="book-author two">by <?php echo $filtered_data[$i]->getClientName(); ?></div>
                <div class="book-sum two"><?php echo $filtered_data[$i]->getDescription(); ?></div>
                <div class="book-see2">Echange</div>
            </div>
        </div>
<?php } } ?>
</div>


<!-- partial -->
  <script src='css/Jquery/flickity-docs.min.js'></script>
<script src='css/Jquery/jquery.min.js'></script>
<script src='script.js'></script>
<link rel="stylesheet" href="css/Interface.js">

</body>
</html>

<style>
  .footer{
bottom:0;
text-align:center;
  }
  .footer p{
    display:inline;
    padding:20px;
  }
</style>
<div class="footer">
      <p>Mano 1946</p>
      <p>Ellias 2006</p>
      <p>Karen 2017</p>
  </div>