<link rel="stylesheet" href="css/Membre.css">

<div class="container">
    <br>
    <div class="creer">
       Liste Membre
    </div>

    <?php for ($i = 1; $i < 42; $i++) { ?>
        <div class="membre">
            <p class="nom">Mano <?php echo $i ?></p>
            <a href="" class="supprimer">Delete</a>
        </div>
    <?php } ?>

  </div>