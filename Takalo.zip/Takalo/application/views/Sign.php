<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Placeholder Animated</title>

  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="header">
    <div class="header-title"><img src="css/logo.png" width="120px" heigth="50px"></div>
    <div class="redirect">
      <p>About Us</p>
      <p>Contact</p>
      <p>Home</p>
      <p>Services</p>
    </div>
    <div class="browse">
     <div class="browse-category">
      Browse Category
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
       <path d="M6 9l6 6 6-6" /></svg>
     </div>
     <div class="search-bar">
      <input type="text" placeholder="Search Book" />
     </div>
    </div>
   </div>

    <div class="container">
      <br>
    <div class="creer">
       <img src="css/logo.png" width="120px">
    </div>

      <form action="<?php echo site_url('SignIn'); ?>" method="post">
        <div class="nom">
          <div class="input-block">
            <input type="text" name="nom" id="input-text" value="Andriasat" required spellcheck="false">
            <span class="placeholder">nom</span>
          </div>

          <div class="input-block">
            <input type="text" name="prenom" id="input-text" value="Mano" required spellcheck="false">
            <span class="placeholder">prenom</span>
          </div>
        </div>

        <div class="mail">
          <div class="input-block">
            <input class="email" type="text" name="mail" id="input-text" value="ManooAndriasat@gmail.com"  required spellcheck="false">
            <span class="placeholder">nom d'utilisateur</span>
          </div>
        </div>
        <div class="conseil">Vous pouvez utiliser des lettres, des chiffres et des points</div>

        <div class="login">
          <a href="Login.html">utiliser mon adresse e-mail actuelle a la place</a>
        </div>
        <br>

        <div class="nom">
          <div class="input-block">
            <input type="text" name="mdp" id="input-text" required spellcheck="false">
            <span class="placeholder">Mot de Passe</span>
          </div>

          <div class="input-block">
            <input type="text" name="mdpc" id="input-text" required spellcheck="false">
            <span class="placeholder">Confirmer</span>
          </div>
        </div>
        <div class="conseil">Utiliser au moins huit caracteres avec des lettres, des chiffres et des symboles</div>

        <div class="box">
          <input type="checkbox" name="ok" id="" checked>Afficher mot de Passe
        </div>

        <div class="mail">
          <div class="input-block">
            <input type="number" name="contact" id="input-text" value="0343373351"  required spellcheck="false">
            <span class="placeholder">contact</span>
          </div>
        </div>
        <div class="conseil">Veuiller mettre un contact valide</div>


        <div class="confirmer">
          <div class="login">
            <a href="<?php echo site_url('Welcome'); ?>">Se connecter a un compte existant</a>
          </div>
          <div class="submit">
            <input type="submit">
          </div>
        </div>

      </form>
      <div class="footer">
        <p>Malagasy(Madagascar)<select name="" id=""></select></p>
        <p>By Mano</p>
        <p>Confidentialite</p>
        <p>Conditions d'utilisation</p>
    </div>
    </div>


</body>
</html>
<style>
  .footer{
bottom:0;
text-align:center;
  }
  .footer p{
    display:inline;
    padding:20px;
  }
</style>
<div class="footer">
      <p>Mano 1946</p>
      <p>Ellias 2006</p>
      <p>Karen 2017</p>
  </div>