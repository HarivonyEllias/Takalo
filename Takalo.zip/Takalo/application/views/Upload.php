<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Placeholder Animated</title>

  <link rel="stylesheet" href="css/style.css">
</head>
<body>


  <div class="header">
    <div class="header-title"><img src="css/logo.png" width="120px" heigth="50px"></div>
    <div class="redirect">
      <p>About Us</p>
      <p>Contact</p>
      <p>Home</p>
      <p>Services</p>
    </div>
    <div class="browse">
     <div class="browse-category">
      Browse Category
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
       <path d="M6 9l6 6 6-6" /></svg>
     </div>
     <div class="search-bar">
      <input type="text" placeholder="Search Book" />
     </div>
    </div>
   </div>


  <div class="container">





    <br>
    <div class="creer">
       <img src="css/logo.png" width="120px">
    </div>



    <form action="<?php echo site_url('Controller_Login'); ?>" method="post">

      <div class="mail">
        <div class="input-block">
          <input class="email" type="text" name="user"  id="input-text"  required spellcheck="false">
          <span class="placeholder">nom d'utilisateur</span>
        </div>
      </div>

      <div class="nom">
        <br>
      <div class="input-block">
        <input type="password" name="pass" value="admin"  id="input-text" required spellcheck="false" style="width:259%">
        <span class="placeholder">Mot de Passe</span>
      </div>

      </div>

      <div class="confirmer">
        <div class="login">
          <a href="<?php echo site_url('Sign'); ?>">Creer un compte</a>
        </div>
        <div class="submit">
          <input type="submit">
        </div>
      </div>
      <div class="confirmer">
        <div class="login">
          <a href="<?php echo site_url('LogAdmin'); ?>">Espace admin</a>
        </div>

    </form>

    <div class="footer">
      <p>Malagasy(Madagascar)<select name="" id=""></select></p>
      <p>By Mano</p>
      <p>Confidentialite</p>
      <p>Conditions d'utilisation</p>
  </div>
  </div>

</body>
</html>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Placeholder Animated</title>

  <link rel="stylesheet" href="css/style.css">
</head>
<body>


  <div class="header">
    <div class="header-title"><img src="css/logo.png" width="120px" heigth="50px"></div>
    <div class="redirect">
      <p>About Us</p>
      <p>Contact</p>
      <p>Home</p>
      <p>Services</p>
    </div>
    <div class="browse">
     <div class="browse-category">
      Browse Category
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
       <path d="M6 9l6 6 6-6" /></svg>
     </div>
     <div class="search-bar">
      <input type="text" placeholder="Search Book" />
     </div>
    </div>
   </div>


  <div class="container">





    <br>
    <div class="creer">
       <img src="css/logo.png" width="120px">
    </div>

    <form action="<?php echo site_url('ObjetController/insert'); ?>" method="post" enctype="multipart/form-data">
  <div>
    <label for="idClient">Client ID:</label>
    <input type="text" id="idClient" name="idClient">
  </div>
  <div>
    <label for="idCategorie">Category ID:</label>
    <input type="text" id="idCategorie" name="idCategorie">
  </div>
  <div>
    <label for="name">Name:</label>
    <input type="text" id="name" name="name">
  </div>
  <div>
    <label for="description">Description:</label>
    <textarea id="description" name="description"></textarea>
  </div>
  <div>
    <label for="image">Image:</label>
    <input type="file" id="image" name="image">
  </div>
  <div>
    <label for="price">Price:</label>
    <input type="text" id="price" name="price">
  </div>
  <div>
    <label for="date">Date:</label>
    <input type="date" id="date" name="date">
  </div>
  <button type="submit">Submit</button>
</form>


    <div class="footer">
      <p>Malagasy(Madagascar)<select name="" id=""></select></p>
      <p>By Mano</p>
      <p>Confidentialite</p>
      <p>Conditions d'utilisation</p>
  </div>
  </div>

</body>
</html>
