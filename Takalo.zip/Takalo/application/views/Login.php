<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Placeholder Animated</title>

  <link rel="stylesheet" href="css/style.css">
</head>
<body>


  <div class="header">
    <div class="header-title"><img src="css/logo.png" width="120px" heigth="50px"></div>
    <div class="redirect">
      <p>About Us</p>
      <p>Contact</p>
      <p>Home</p>
      <p>Services</p>
    </div>
    <div class="browse">
     <div class="browse-category">
      Browse Category
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
       <path d="M6 9l6 6 6-6" /></svg>
     </div>
     <div class="search-bar">
      <input type="text" placeholder="Search Book" />
     </div>
    </div>
   </div>


  <div class="container">





    <br>
    <div class="creer">
       <img src="css/logo.png" width="120px">
    </div>



    <form action="<?php echo site_url('Controller_Login'); ?>" method="post">

      <div class="mail">
        <div class="input-block">
          <input class="email" type="text" name="user"  id="input-text"  required spellcheck="false">
          <span class="placeholder">nom d'utilisateur</span>
        </div>
      </div>

      <div class="nom">
        <br>
      <div class="input-block">
        <input type="password" name="pass" value="admin"  id="input-text" required spellcheck="false" style="width:259%">
        <span class="placeholder">Mot de Passe</span>
      </div>

      </div>

      <div class="confirmer">
        <div class="login">
          <a href="<?php echo site_url('Sign'); ?>">Creer un compte</a>
        </div>
        <div class="submit">
          <input type="submit">
        </div>
      </div>
      <div class="confirmer">
        <div class="login">
          <a href="<?php echo site_url('LogAdmin'); ?>">Espace admin</a>
        </div>

    </form>

    <style>
  .footer{
bottom:0;
text-align:center;
  }
  .footer p{
    display:inline;
    padding:20px;
  }
</style>
<div class="footer">
      <p>Mano 1946</p>
      <p>Ellias 2006</p>
      <p>Karen 2017</p>
  </div>
  </div>
  
</body>
</html>
