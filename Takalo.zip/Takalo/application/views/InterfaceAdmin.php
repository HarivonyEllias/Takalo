<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Book Store UI</title>
  <link rel='stylesheet' href='css/Jquery/flickity.css'>
  <link rel="stylesheet" href="css/Interface.css">
  <link rel="stylesheet" href="css/SideBar.css">
  <link rel='stylesheet' href='css/fontawesome/css/all.css'>

</head>
<body>


<nav class="main-menu">
            <ul>
                <li>
                    <a href="#">
                        <i class="fa fa-home"></i>
                        <span class="nav-text">
                            Ajout/suppr Categorie
                        </span>
                    </a>
                  
                </li>
                <li class="has-subnav">
                    <a href="#">
                        <i class="fa fa-laptop fa-2x"></i>
                        <span class="nav-text">
                            Liste Membre
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-list fa-2x"></i>
                        <span class="nav-text">
                            Liste Objets
                        </span>
                    </a>
                    <li>

           
                   <a href="<?php echo site_url('LogOut'); ?>">
                         <i class="fa fa-power-off fa-2x"></i>
                        <span class="nav-text">
                            Logout
                        </span>
                    </a>
                </li>  
           
        </nav>


<div class="book-store">
 <div class="header">
  <div class="header-title"><img src="css/logo.png" width="120px" heigth="50px"></div>

  <div class="browse">
   <div class="browse-category">
    Browse Category
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
     <path d="M6 9l6 6 6-6" /></svg>
   </div>

   <div class="search-bar">
    <input type="text" placeholder="Search Book" />
   </div>


  </div>
 </div>

  <script src='css/Jquery/flickity-docs.min.js'></script>
<script src='css/Jquery/jquery.min.js'></script>
<script src='css/Interface.js'></script>


<?php $this->load->view('ListeObjet'); ?>

</body>
</html>
<style>
  .footer{
bottom:0;
text-align:center;
  }
  .footer p{
    display:inline;
    padding:20px;
  }
</style>
<div class="footer">
      <p>Mano 1946</p>
      <p>Ellias 2006</p>
      <p>Karen 2017</p>
  </div>
