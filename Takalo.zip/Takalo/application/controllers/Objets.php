<?php
class Objets extends CI_Controller {

    public function addObjet() {
        // load the model
        $this->load->model('Objet');

        // get the form data
        $idClient = $this->input->post('idClient');
        $idCategorie = $this->input->post('idCategorie');
        $name = $this->input->post('name');
        $description = $this->input->post('description');
        $price = $this->input->post('price');

        // get the image
        $image = $_FILES['image']['name'];

        // set the object data
        $objet = new Objet();
        $objet->idClient = $idClient;
        $objet->idCategorie = $idCategorie;
        $objet->name = $name;
        $objet->description = $description;
        $objet->image = $image;
        $objet->price = $price;
        $objet->date = date('Y-m-d');

        // insert the object into the database
        $this->Objet->insert($objet);

        // upload the image
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 100;
        $config['max_width'] = 1024;
        $config['max_height'] = 768;
        $this->load->library('upload', $config);
        $this->upload->do_upload('image');

        // redirect to the objects list
        redirect('Welcome');
    }
}

?>