<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class SignIn extends CI_Controller {

    public function index()
    {
        if($this->input->post()) {
            $name = $this->input->post('nom') . ' ' . $this->input->post('prenom');
            $email = $this->input->post('mail');
            $password = $this->input->post('mdp');

            $this->load->model('Client');
            $result = $this->Client->insert_client($name, $email, $password);

            if($result) {
                redirect(base_url('Welcome'));
            } else {
                redirect(base_url('SignIn'));
            }
        } else {
            $this->load->view('SignIn');
        }
    }

}
