<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controller_LoginAdmin extends CI_Controller {
    public function index(){        
        $this->load->library('session');
        $this->load->helper('url');
        if($this->input->post('user')=='admin' &&  $this->input->post('pass')=="admin"){
            $this->session->set_userdata('user', 'admin');
            $this->load->view('InterfaceAdmin');
        }else{
            redirect(base_url('LogAdmin'));
        }
    }
}
