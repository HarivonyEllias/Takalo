<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controller_Login extends CI_Controller {
    public function index(){
        $this->load->model('Client');
        $this->load->library('session');
        $this->load->helper('url');
        if($this->input->post('user')=='admin' &&  $this->input->post('pass')=="admin"){
            $this->session->set_userdata('user','admin');
            $this->load->view('Interface');
        }else{
            $client=new Client();
            $client->setName($this->input->post('user'));
            $client->setPassword($this->input->post('pass'));
            if($client->check()){
                $this->session->set_userdata('user', $this->input->post('user'));
                $this->load->view('Interface');
            }else{
                redirect(base_url('Welcome'));
            }
        }
    }
}

