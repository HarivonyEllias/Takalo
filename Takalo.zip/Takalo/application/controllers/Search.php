<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
    }
    public function index(){  
        $username = $this->session->userdata('username');
        $data['username'] = $username;
        $this->load->model('Objet');
        $obj=new Objet();     
        $data['search_result']=$obj->search($this->input->get('search'),$this->input->get('category_filter'));
        $this->load->view('Interface',$data);    
    }
}
