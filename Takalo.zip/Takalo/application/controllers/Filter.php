<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Filter extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
    }
    public function index(){  
        $username = $this->session->userdata('username');
        $data['username'] = $username;
        $this->load->model('Categorie');
        $this->load->model('Objet');
        $cat=new Categorie();
        $cat->setIdCategorie($this->input->get('idcategorie'));     
        $data['filtered_data']=$cat->getAllObjet();
        $this->load->view('Interface',$data);
    }
}
