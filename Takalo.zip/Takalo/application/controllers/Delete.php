<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Delete extends CI_Controller {
    public function index(){        
        $this->load->model('Objet');
        $o=new Objet();
        $o->setIdObjet($this->input->get('id'));
        $o->delete();
		$this->load->view('InterfaceAdmin');
    }       
}
