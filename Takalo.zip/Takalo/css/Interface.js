const toggleButton = document.querySelector('.main-menu');
toggleButton.addEventListener('click', () => { document.body.classList.toggle('affiche'); });
