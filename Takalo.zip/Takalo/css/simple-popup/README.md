# Simple PopUp

A Pen created on CodePen.io. Original URL: [https://codepen.io/lupitot/pen/mdjoWWX](https://codepen.io/lupitot/pen/mdjoWWX).

Here's a simple pop-up with a little bit of JS.
Here, I wanted to show how to make a pop-up, because it is an important element and not necessarily intuitive when you start.