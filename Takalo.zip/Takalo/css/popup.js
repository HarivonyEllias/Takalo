function Show(){
    divInfo = document.getElementById('popupdiv');
    if (divInfo.style.display == 'none'){
        divInfo.style.display = 'block';
        localStorage.setItem('popupStatus', 'visible');
    }else{
        divInfo.style.display = 'none';
        localStorage.setItem('popupStatus', 'hidden');
    }
    
}

window.onload = function() {
    divInfo = document.getElementById('popupdiv');
    if (localStorage.getItem('popupStatus') == 'visible') {
        divInfo.style.display = 'block';
    } else {
        divInfo.style.display = 'none';
    }
}

function Hide(){
    divInfo = document.getElementById('popupdiv');
    divInfo.style.display = 'none';
    localStorage.setItem('popupStatus', 'hidden');
}

function Showw(){
    divInfo = document.getElementById('popupdivv');
    if (divInfo.style.display == 'none'){
        divInfo.style.display = 'block';
        localStorage.setItem('popupStatus', 'visible');
    }else{
        divInfo.style.display = 'none';
        localStorage.setItem('popupStatus', 'hidden');
    }
    
}

function Hidee(){
    divInfo = document.getElementById('popupdivv');
    divInfo.style.display = 'none';
    localStorage.setItem('popupStatus', 'hidden');
}
